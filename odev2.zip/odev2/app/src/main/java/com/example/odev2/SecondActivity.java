package com.example.odev2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    Intent intent;
    Bundle bundle;
    ArrayList<FilmDetay> filmDetayList;

    Spinner spinnerFilmler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        spinnerFilmler = findViewById(R.id.spinner_filmler);

        intent = getIntent();
        bundle = intent.getExtras();
        filmDetayList = bundle.getParcelableArrayList("filmler");

        System.out.println("film : " + filmDetayList.size());

        SpinnerAdapter spinnerAdapter = new SpinnerAdapter(this, R.layout.filmler_spinner, filmDetayList);

        spinnerFilmler.setAdapter(spinnerAdapter);


    }

    public void onClick(View view) {

        Intent intent1 = new Intent(this,ThirdActivity.class);
        Bundle bundle1 = new Bundle();
        FilmDetay filmDetay = filmDetayList.get(spinnerFilmler.getSelectedItemPosition());
        bundle1.putParcelable("filmDetay",filmDetay);
        intent1.putExtras(bundle1);
        startActivityForResult(intent1,1);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bundle bundleData = data.getExtras();
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "En Son Tıklanan Film : " + bundleData.getString("filmAd"), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Opp! Geri donuste bir haa oldu!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
